public class Ogre extends Enemy {
    public Ogre () {
        super("Ogre", 30, 20);
    }
}
