public class Pillow extends Weapon{
    public Pillow() {
        super("Pillow", "A pillow is super soft.", 1, 1);
    }
}
