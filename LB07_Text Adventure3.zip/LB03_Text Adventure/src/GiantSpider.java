public class GiantSpider extends Enemy {
    public GiantSpider () {
        super ("GiantSpider", 10, 2);
    }
}
