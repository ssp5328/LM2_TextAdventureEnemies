public class Dog extends Enemy {
    public Dog () {
        super ("Dog", 20, 15);
    }
}
