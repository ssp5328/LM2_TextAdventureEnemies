public class Arrow extends Weapon {
    public Arrow() {
        super("Bow and Arrow", "Bow and Arrow. Somewhat more dangerous than a Dagger.", 11, 31);
    }
}