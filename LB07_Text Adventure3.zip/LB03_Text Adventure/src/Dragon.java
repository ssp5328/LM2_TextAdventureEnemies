public class Dragon extends Enemy {
    public Dragon () {
        super ("Dragon", 50, 100);
    }
}
