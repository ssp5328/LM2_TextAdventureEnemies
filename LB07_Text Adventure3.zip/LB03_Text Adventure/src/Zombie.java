public class Zombie extends Enemy {
    public Zombie () {
        super ("Zombie", 20, 15);
    }
}
