public class Sword extends Weapon{
    public Sword() {
        super("Sword", "A Sword with some rust. Somewhat more dangerous than a dagger.", 10, 20);
    }
}
