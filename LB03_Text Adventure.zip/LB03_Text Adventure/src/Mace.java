public class Mace extends Weapon{
    public Mace() {
        super("Mace", "A Mace. Somewhat more dangerous than a Sword.", 10, 30);
    }
}